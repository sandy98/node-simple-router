

<?php
 echo "<title>A simple PHP proof of concept</title>";
 echo "<h1 style='text-align: center; color: #f24; font-size: 24pt; text-shadow: 3px 3px gray;'>PHP Info for Node.js</h1>";
 phpinfo();
?>
