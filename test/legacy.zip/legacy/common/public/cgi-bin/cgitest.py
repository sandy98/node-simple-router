#!/usr/bin/env python2

import cgi

cgi.test()